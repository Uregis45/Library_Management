<?php require_once __DIR__.'/../includes/auth.php'; require_login(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Digital Library</title>

<style>
:root{
    --green:#22c55e;
    --green-soft:#4ade80;
    --dark:#020617;
    --glass:rgba(255,255,255,0.06);
    --border:rgba(34,197,94,0.35);
    --text:#e5e7eb;
    --muted:#9ca3af;
}

/* RESET */
*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    font-family: "Segoe UI", system-ui, sans-serif;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    background:
      radial-gradient(circle at top, #022c22, transparent 45%),
      radial-gradient(circle at bottom, #020617, transparent 45%),
      var(--dark);
    color:var(--text);
}

/* MAIN SECTION */
.filter-section{
    width:95%;
    max-width:1200px;
    padding:45px 35px;
    border-radius:22px;
    background:linear-gradient(135deg,
        rgba(255,255,255,0.08),
        rgba(255,255,255,0.02));
    backdrop-filter: blur(14px);
    border:1px solid var(--border);
    box-shadow:
        0 30px 60px rgba(0,0,0,0.65),
        inset 0 0 40px rgba(34,197,94,0.06);
    text-align:center;
}

/* TITLE */
.library-title{
    font-size:2.5rem;
    font-weight:800;
    margin-bottom:10px;
    background:linear-gradient(135deg,var(--green),var(--green-soft));
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

/* SUBTITLE */
.library-subtitle{
    font-size:1.1rem;
    color:var(--muted);
    margin-bottom:40px;
}

/* DIVIDER TEXT */
.section-divider{
    font-weight:700;
    letter-spacing:2px;
    color:var(--green-soft);
    margin:40px 0 25px;
    position:relative;
}

.section-divider::before,
.section-divider::after{
    content:"";
    position:absolute;
    top:50%;
    width:25%;
    height:2px;
    background:linear-gradient(to right,transparent,var(--green));
}

.section-divider::after{
    right:0;
    background:linear-gradient(to left,transparent,var(--green));
}

.section-divider::before{
    left:0;
}

/* LANGUAGE GRID */
.main-tabs{
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap:20px;
    justify-items:center;
    align-items:center;
    margin-bottom:20px;
}

/* BUTTONS */
.main-btn{
    display:inline-block;
    width:100%;
    padding:15px 10px;
    border-radius:15px;
    font-size:1rem;
    font-weight:600;
    color:var(--text);
    text-decoration:none;
    background:var(--glass);
    border:1px solid var(--border);
    position:relative;
    overflow:hidden;
    transition: all 0.35s ease;
}

/* LIGHT SWEEP */
.main-btn::before{
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(
        120deg,
        transparent,
        rgba(255,255,255,0.35),
        transparent
    );
    transform:translateX(-100%);
    transition:0.6s;
}

.main-btn:hover::before{
    transform:translateX(100%);
}

/* HOVER EFFECT */
.main-btn:hover{
    background:linear-gradient(135deg,var(--green),var(--green-soft));
    color:#020617;
    transform:translateY(-5px) scale(1.05);
    box-shadow:
        0 0 25px rgba(34,197,94,0.7),
        0 0 50px rgba(34,197,94,0.35);
}

/* RESPONSIVE */
@media(max-width:600px){
    .library-title{
        font-size:2rem;
    }
    .library-subtitle{
        font-size:1rem;
    }
    .main-btn{
        padding:12px 8px;
        font-size:0.95rem;
    }
}
</style>
</head>

<body>

<div class="filter-section">
    <div class="library-title">Digital Library</div>
    <div class="library-subtitle">Choose the language you want to learn</div>

    <div class="section-divider">LANGUAGES</div>

    <div class="main-tabs">
        <a href="language-learning/english.html" class="main-btn">English</a>
        <a href="language-learning/french.html" class="main-btn">French</a>
        <a href="language-learning/german.html" class="main-btn">German</a>
        <a href="language-learning/kinyarwanda.html" class="main-btn">Kinyarwanda</a>
        <a href="language-learning/spanish.html" class="main-btn">Spanish</a>
        <a href="language-learning/chinese.html" class="main-btn">Chinese</a>
        <a href="language-learning/japanese.html" class="main-btn">Japanese</a>
        <a href="language-learning/kiswahili.html" class="main-btn">Kiswahili</a>
        <a href="language-learning/hindi.html" class="main-btn">Hindi</a>
    </div>
</div>

</body>
</html>
