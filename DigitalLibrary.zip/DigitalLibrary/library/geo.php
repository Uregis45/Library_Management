<?php require_once __DIR__.'/../includes/auth.php'; require_login(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Geography Books Library</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">

<style>
/* --- CSS VARIABLES & RESET --- */
:root {
    --bg-deep: #0f172a;
    --bg-surface: #1e293b;
    --primary: #38bdf8; /* Ocean Blue */
    --secondary: #818cf8; /* Indigo (Atmosphere) */
    --accent: #4ade80; /* Land Green */
    --glass-bg: rgba(30, 41, 59, 0.7);
    --glass-border: rgba(255, 255, 255, 0.1);
    --text-main: #f8fafc;
    --text-muted: #94a3b8;
    --shadow-lg: 0 10px 40px -10px rgba(0,0,0,0.5);
    --card-hover-transform: translateY(-8px);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: var(--bg-deep);
    color: var(--text-main);
    overflow-x: hidden;
    line-height: 1.6;
}

/* --- BACKGROUND ANIMATION CANVAS --- */
#geo-canvas {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    pointer-events: none;
    background: radial-gradient(circle at 50% 50%, #1e293b 0%, #0f172a 100%);
}

/* --- HERO SECTION --- */
.hero {
    min-height: 80vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 100px 20px 50px;
    position: relative;
}

.hero h1 {
    font-size: clamp(2.5rem, 5vw, 4.5rem);
    font-weight: 700;
    background: linear-gradient(135deg, var(--primary), var(--accent), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 20px;
    text-shadow: 0 10px 30px rgba(56, 189, 248, 0.2);
    animation: fadeInDown 1s ease-out;
}

.hero p {
    font-size: 1.25rem;
    color: var(--text-muted);
    max-width: 600px;
    margin-bottom: 40px;
    animation: fadeInUp 1s ease-out 0.3s backwards;
}

/* --- NAVIGATION --- */
nav {
    position: sticky;
    top: 20px;
    z-index: 100;
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-bottom: 60px;
    padding: 10px;
    background: rgba(15, 23, 42, 0.6);
    backdrop-filter: blur(12px);
    border: 1px solid var(--glass-border);
    border-radius: 50px;
    width: fit-content;
    margin-left: auto;
    margin-right: auto;
    box-shadow: var(--shadow-lg);
    animation: fadeInUp 1s ease-out 0.6s backwards;
    flex-wrap: wrap;
}

nav a {
    padding: 12px 28px;
    border-radius: 30px;
    text-decoration: none;
    color: var(--text-muted);
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

nav a:hover, nav a.active {
    color: var(--bg-deep);
    background: var(--primary);
    box-shadow: 0 0 20px rgba(56, 189, 248, 0.4);
    transform: scale(1.05);
}

/* --- MAIN CONTAINER --- */
main {
    max-width: 1200px;
    margin: auto;
    padding: 0 20px 100px;
}

/* --- SECTION STYLING --- */
.section-title {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 40px;
    margin-top: 80px;
    padding-bottom: 15px;
    border-bottom: 1px solid var(--glass-border);
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.8s ease;
}

.section-title.visible {
    opacity: 1;
    transform: translateY(0);
}

.section-title span {
    font-size: 2.5rem;
    background: linear-gradient(135deg, var(--text-main), var(--text-muted));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-family: 'JetBrains Mono', monospace;
}

.section-title h2 {
    font-size: 2rem;
    font-weight: 600;
    color: var(--text-main);
    letter-spacing: -0.5px;
}

/* --- BOOK GRID --- */
.books {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
}

/* --- BOOK CARD (Glassmorphism & 3D) --- */
.book {
    background: var(--glass-bg);
    border: 1px solid var(--glass-border);
    border-radius: 20px;
    padding: 25px;
    position: relative;
    overflow: hidden;
    backdrop-filter: blur(10px);
    transition: all 0.4s ease;
    transform-style: preserve-3d;
    opacity: 0;
    transform: translateY(30px);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.book.visible {
    opacity: 1;
    transform: translateY(0);
}

.book:hover {
    transform: translateY(-10px) rotateX(2deg);
    border-color: rgba(74, 222, 128, 0.3);
    box-shadow: 0 20px 50px -12px rgba(74, 222, 128, 0.15);
    background: rgba(30, 41, 59, 0.9);
}

.book::before {
    content: attr(data-icon);
    position: absolute;
    top: -20px;
    right: -20px;
    font-size: 10rem;
    opacity: 0.03;
    transform: rotate(-15deg);
    font-family: 'JetBrains Mono', monospace;
    pointer-events: none;
    transition: all 0.5s ease;
}

.book:hover::before {
    opacity: 0.06;
    top: -30px;
    right: -30px;
}

.book-title {
    font-size: 1.15rem;
    font-weight: 600;
    margin-bottom: 20px;
    color: var(--text-main);
    position: relative;
    z-index: 1;
    min-height: 60px; /* Align buttons */
}

/* --- BUTTONS --- */
.book a, .btn-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 12px 20px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.9rem;
    background: linear-gradient(135deg, rgba(56, 189, 248, 0.1), rgba(74, 222, 128, 0.05));
    border: 1px solid var(--glass-border);
    color: var(--primary);
    transition: all 0.3s ease;
    width: 100%;
    position: relative;
    z-index: 1;
    overflow: hidden;
}

.book a:hover {
    background: var(--accent);
    color: var(--bg-deep);
    box-shadow: 0 0 25px rgba(74, 222, 128, 0.4);
}

/* --- FOOTER --- */
footer {
    text-align: center;
    padding: 40px 20px;
    background: rgba(15, 23, 42, 0.9);
    border-top: 1px solid var(--glass-border);
    color: var(--text-muted);
    font-size: 0.9rem;
    margin-top: 50px;
}

footer span {
    color: var(--accent);
}

@keyframes fadeInDown {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}

@media (max-width: 768px) {
    .hero h1 { font-size: 2.5rem; }
    nav { width: 95%; top: 10px; }
    .books { grid-template-columns: 1fr; }
}
</style>
</head>

<body>

<canvas id="geo-canvas"></canvas>

<section class="hero">
    <h1>🌍 Geography Books Library</h1>
    <p>Extensive collection of free Geography, GIS, and Earth Science resources.</p>
</section>

<!-- NAVIGATION -->
<nav>
    <a href="#secondary">Secondary School</a>
    <a href="#physical">Physical Geo</a>
    <a href="#human">Human Geo</a>
    <a href="#gis">GIS & Tech</a>
</nav>

<main>

<!-- SECONDARY SCHOOL -->
<div class="section-title" id="secondary">
    <span>🎓</span>
    <h2>Secondary School (NCERT)</h2>
</div>
<div class="books secondary">
    <div class="book" data-icon="G9">
        <div class="book-title">Fundamentals of Physical Geography (Class 11)</div>
        <a href="https://ncert.nic.in/textbook/pdf/kegy101.pdf" target="_blank">📖 Download PDF</a>
    </div>
    <div class="book" data-icon="G10">
        <div class="book-title">India: Physical Environment (Class 11)</div>
        <a href="https://ncert.nic.in/textbook/pdf/kegy102.pdf" target="_blank">📖 Download PDF</a>
    </div>
    <div class="book" data-icon="G11">
        <div class="book-title">Practical Work in Geography (Class 11)</div>
        <a href="https://ncert.nic.in/textbook/pdf/kegy103.pdf" target="_blank">🗺️ Download PDF</a>
    </div>
    <div class="book" data-icon="G12">
        <div class="book-title">Fundamentals of Human Geography (Class 12)</div>
        <a href="https://ncert.nic.in/textbook/pdf/legy101.pdf" target="_blank">👥 Download PDF</a>
    </div>
    <div class="book" data-icon="G13">
        <div class="book-title">People and Economy (Class 12)</div>
        <a href="https://ncert.nic.in/textbook/pdf/legy103.pdf" target="_blank">🏙️ Download PDF</a>
    </div>
    <div class="book" data-icon="G14">
        <div class="book-title">Contemporary World Politics (Geo Context)</div>
        <a href="https://ncert.nic.in/textbox/pdf/leph101.pdf" target="_blank">🌐 Download PDF</a>
    </div>
</div>

<!-- PHYSICAL GEOGRAPHY -->
<div class="section-title" id="physical">
    <span>🏔️</span>
    <h2>Physical Geography & Earth Science</h2>
</div>
<div class="books physical">
    <div class="book" data-icon="Phys">
        <div class="book-title">The Physical Environment (Free Textbook)</div>
        <a href="https://www.physicalgeography.net/fundamentals/contents.html" target="_blank">🌋 Read Online</a>
    </div>
    <div class="book" data-icon="Geo">
        <div class="book-title">Introduction to Geology (OpenStax)</div>
        <a href="https://openstax.org/details/books/introduction-geology" target="_blank">🪨 Read PDF</a>
    </div>
    <div class="book" data-icon="Ocean">
        <div class="book-title">Introduction to Oceanography</div>
        <a href="https://open.umn.edu/opentextbooks/textbooks/introduction-to-oceanography" target="_blank">🌊 Read PDF</a>
    </div>
    <div class="book" data-icon="Climate">
        <div class="book-title">Climatology & Atmosphere</div>
        <a href="https://www.britannica.com/science/climatology" target="_blank">☁️ Read Article</a>
    </div>
    <div class="book" data-icon="Bio">
        <div class="book-title">Biogeography: Introduction</div>
        <a href="https://www.nature.com/scitable/knowledge/library/biogeography-13227831/" target="_blank">🌿 Read Article</a>
    </div>
    <div class="book" data-icon="Hydro">
        <div class="book-title">Hydrology & Water Resources</div>
        <a href="https://usgs.gov/special-topics/water-science-school" target="_blank">💧 Read Guide</a>
    </div>
</div>

<!-- HUMAN GEOGRAPHY -->
<div class="section-title" id="human">
    <span>🏙️</span>
    <h2>Human & Regional Geography</h2>
</div>
<div class="books human">
    <div class="book" data-icon="World">
        <div class="book-title">World Regional Geography (OpenStax)</div>
        <a href="https://openstax.org/details/books/world-regional-geography" target="_blank">🌍 Read PDF</a>
    </div>
    <div class="book" data-icon="Urban">
        <div class="book-title">Urban Geography (Saylor Academy)</div>
        <a href="https://resources.saylor.org/wwwresources/archived/site/textbooks/Urban%20Geography.pdf" target="_blank">🏙️ Download PDF</a>
    </div>
    <div class="book" data-icon="Econ">
        <div class="book-title">Economic Geography (Global)</div>
        <a href="https://open.umn.edu/opentextbooks/textbooks/world-regional-geography-people-places-and-globalization" target="_blank">📈 Read PDF</a>
    </div>
    <div class="book" data-icon="Cult">
        <div class="book-title">Cultural Geography (MIT OCW)</div>
        <a href="https://ocw.mit.edu/courses/11-401-introduction-to-housing-community-and-economic-development-fall-2005/" target="_blank">🎭 View Course</a>
    </div>
    <div class="book" data-icon="Pop">
        <div class="book-title">Population Geography</div>
        <a href="https://www.britannica.com/science/population-geography" target="_blank">👨‍👩‍👧‍👦 Read Article</a>
    </div>
    <div class="book" data-icon="Dev">
        <div class="book-title">Development Geography</div>
        <a href="https://www.routledge.com/Development-Geography/Routledge/p/book/9781138653362" target="_blank">🚀 View Details</a>
    </div>
</div>

<!-- GIS & TECHNOLOGY -->
<div class="section-title" id="gis">
    <span>🛰️</span>
    <h2>GIS, Remote Sensing & Cartography</h2>
</div>
<div class="books gis">
    <div class="book" data-icon="GIS">
        <div class="book-title">QGIS Training Manual (Official)</div>
        <a href="https://docs.qgis.org/3.28/en/docs/training_manual/" target="_blank">📖 Read Online</a>
    </div>
    <div class="book" data-icon="Remote">
        <div class="book-title">Remote Sensing Basics (NASA)</div>
        <a href="https://earthobservatory.nasa.gov/features/RemoteSensing/" target="_blank">🛰️ Read Guide</a>
    </div>
    <div class="book" data-icon="Map">
        <div class="book-title">Principles of Cartography</div>
        <a href="https://www.e-education.psu.edu/geog486/" target="_blank">🗺️ Read Course</a>
    </div>
    <div class="book" data-icon="Data">
        <div class="book-title">Geospatial Analysis (Webbook)</div>
        <a href="https://www.spatialanalysisonline.com/" target="_blank">💻 Read Online</a>
    </div>
    <div class="book" data-icon="Python">
        <div class="book-title">Python for Geospatial Analysis</div>
        <a href="https://automating-gis-processes.github.io/site/" target="_blank">🐍 Read Tutorial</a>
    </div>
    <div class="book" data-icon="Sat">
        <div class="book-title">Landsat Mission (Satellite Data)</div>
        <a href="https://landsat.gsfc.nasa.gov/" target="_blank">📡 Access Data</a>
    </div>
</div>

</main>

<footer>
    © 2026 Geography Books Library • <span>Explore the World Free</span>
</footer>

<script>
    /**
     * ANIMATION ENGINE
     * Handles the floating geographical icons background
     * and scroll reveal interactions.
     */
    
    const canvas = document.getElementById('geo-canvas');
    const ctx = canvas.getContext('2d');

    let width, height;
    let particles = [];

    // Expanded set of Geography symbols
    const symbols = ['🌍', '🌎', '🌏', '🗺️', '🧭', '🏔️', '🌊', '🌲', '☁️', '✈️', '🛰️', '🏙️', '🌋', '🚜', '📡'];

    function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    }

    class Particle {
        constructor() {
            this.reset();
            this.y = Math.random() * height;
        }

        reset() {
            this.x = Math.random() * width;
            this.y = height + 50;
            this.speed = 0.5 + Math.random() * 1.5;
            this.symbol = symbols[Math.floor(Math.random() * symbols.length)];
            this.size = 14 + Math.random() * 20;
            this.opacity = 0.05 + Math.random() * 0.15;
            this.drift = (Math.random() - 0.5) * 0.5;
        }

        update() {
            this.y -= this.speed;
            this.x += this.drift;

            if (this.y < -50) {
                this.reset();
            }
        }

        draw() {
            ctx.font = `${this.size}px 'JetBrains Mono'`;
            ctx.fillStyle = `rgba(148, 163, 184, ${this.opacity})`;
            ctx.fillText(this.symbol, this.x, this.y);
        }
    }

    function initParticles() {
        particles = [];
        const particleCount = Math.min(window.innerWidth / 12, 80); // Slightly more particles for richness
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animate);
    }

    function setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: "0px 0px -50px 0px"
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        const elementsToAnimate = document.querySelectorAll('.section-title, .book');
        elementsToAnimate.forEach(el => observer.observe(el));
    }

    window.addEventListener('resize', () => {
        resize();
        initParticles();
    });

    document.addEventListener('DOMContentLoaded', () => {
        resize();
        initParticles();
        animate();
        setupScrollAnimations();
    });

</script>
</body>
</html>