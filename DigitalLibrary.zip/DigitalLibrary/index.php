<?php require_once __DIR__.'/includes/auth.php'; require_login(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Digital Library — Browse Books</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg-color: #0a0a0a;
    --card-color: #1a1a1a;
    --nav-color: #111;
    --text-color: #f0f0f0;
    --accent-color: tomato; 
    --accent-hover: #ff4500;
    --continent-color: #ffd700; /* Gold */
    --continent-hover: #ffea00;
    --highlight-color: #00cc44; 
    --shadow: 0 10px 20px rgba(0,0,0,0.5);
}

html { scroll-behavior: smooth; }

body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: var(--bg-color);
    color: var(--text-color);
    line-height: 1.6;
    overflow-x: hidden;
}

/* HEADER/NAVBAR */
nav {
    background: rgba(10,10,10,0.92);
    backdrop-filter: blur(16px);
    padding: 0 48px;
    height: 64px;
    position: sticky;
    top: 0;
    z-index: 1000;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(255,99,71,0.25);
    box-shadow: 0 4px 24px rgba(0,0,0,0.6);
}

@keyframes gradientShift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.logo {
    font-size: 2.4rem;
    font-weight: 900;
    background: linear-gradient(270deg, #00ff99, #00ccff, #ff00ff, #ffdd00);
    background-size: 600% 600%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: 2.5px;
    text-transform: uppercase;
    cursor: pointer;
    animation: gradientShift 8s ease infinite;
    text-decoration: none;
    transition: transform 0.3s ease, text-shadow 0.3s ease;
}

.logo:hover { transform: scale(1.15); text-shadow: 0 0 20px rgba(0,255,255,0.8); }

.nav-links {
    list-style: none;
    display: flex;
    align-items: center;
    gap: 4px;
    margin: 0;
    padding: 0;
}
.nav-links a {
    color: rgba(255,255,255,0.7);
    text-decoration: none;
    font-weight: 500;
    font-size: 0.9rem;
    padding: 7px 16px;
    border-radius: 8px;
    transition: all 0.2s;
    white-space: nowrap;
}
.nav-links a:hover { color: #fff; background: rgba(255,255,255,0.08); }
.nav-links a.active { color: #fff; background: rgba(255,99,71,0.15); }
.nav-links .nav-cta {
    background: tomato;
    color: #fff !important;
    font-weight: 600;
    padding: 8px 20px;
    border-radius: 8px;
    margin-left: 8px;
}
.nav-links .nav-cta:hover { background: #ff4500; transform: translateY(-1px); }

/* HERO SECTION */
.hero {
    height: 80vh;
    background: linear-gradient(rgba(0,0,0,0.75), rgba(0,0,0,0.75)), 
    url('https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&q=80&w=1920');
    background-size: cover; background-position: center;
    display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; padding: 0 20px;
}

.hero h1 { font-size: 3.5rem; margin-bottom: 20px; text-shadow: 2px 2px 10px rgba(0,0,0,0.8); }
.hero p { font-size: 1.2rem; max-width: 700px; margin-bottom: 30px; color: #ddd; }
.cta-btn {
    background-color: var(--accent-color); color: white; padding: 15px 30px;
    text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 1.1rem; transition: 0.3s;
}
.cta-btn:hover { background-color: var(--accent-hover); transform: translateY(-3px); }

.section-title {
    text-align: center; font-size: 2.5rem; margin-top: 80px; margin-bottom: 40px;
    color: var(--accent-color); text-transform: uppercase; letter-spacing: 2px;
}

/* FEATURES */
.features { display: flex; justify-content: center; flex-wrap: wrap; gap: 30px; padding: 20px; max-width: 1200px; margin: 0 auto; }
.feature-box {
    background-color: var(--card-color); padding: 30px; border-radius: 10px;
    width: 300px; text-align: center; border: 1px solid #333; transition: 0.3s;
}
.feature-box:hover { border-color: var(--highlight-color); transform: translateY(-5px); }
.feature-box h3 { color: var(--highlight-color); }

/* FILTERS */
.filter-section { display: flex; flex-direction: column; align-items: center; gap: 10px; margin-bottom: 30px; }
.main-tabs { display: flex; justify-content: center; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; }
.main-btn {
    background-color: transparent; border: 2px solid var(--accent-color); color: var(--accent-color);
    padding: 10px 25px; border-radius: 25px; cursor: pointer; font-weight: 600; transition: 0.3s;
    font-family: 'Poppins', sans-serif; font-size: 1rem; text-decoration: none;
}
.main-btn:hover, .main-btn.active {
    background-color: var(--accent-color); color: white; transform: scale(1.05);
    box-shadow: 0 0 15px rgba(255, 99, 71, 0.6);
}

.sub-tabs { display: flex; justify-content: center; flex-wrap: wrap; gap: 8px; animation: fadeIn 0.5s ease-in-out; }
.sub-btn {
    background-color: transparent; border: 1px solid var(--continent-color); color: var(--continent-color);
    padding: 6px 20px; border-radius: 20px; cursor: pointer; font-weight: 600; transition: 0.3s;
    font-family: 'Poppins', sans-serif; font-size: 0.9rem;
}
.sub-btn:hover, .sub-btn.active {
    background-color: var(--continent-color); color: black; transform: scale(1.05);
}
@keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

/* BOOKS */
.search-container { text-align: center; margin-bottom: 30px; }
#searchInput {
    width: 60%; max-width: 500px; padding: 15px; border-radius: 30px; border: 2px solid #333;
    background-color: #1a1a1a; color: white; font-size: 1rem; outline: none; transition: 0.3s;
}
#searchInput:focus { border-color: var(--accent-color); box-shadow: 0 0 10px rgba(255, 99, 71, 0.5); }

.container {
    max-width: 1400px; margin: 0 auto 50px auto; padding: 0 20px;
    display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 30px;
}

.book-card {
    background-color: var(--card-color); border-radius: 15px; box-shadow: var(--shadow); overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease; display: flex; flex-direction: column;
    position: relative; border: 1px solid #333;
}
.book-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.6); border-color: var(--accent-color); }

.category-badge, .continent-badge {
    position: absolute; top: 10px; padding: 5px 10px; border-radius: 20px; font-size: 0.7rem; font-weight: bold; z-index: 2;
}
.category-badge { right: 10px; background-color: var(--highlight-color); color: black; }
.continent-badge { left: 10px; background-color: var(--continent-color); color: black; display: none; }

.book-card img { width: 100%; height: 320px; object-fit: cover; border-bottom: 1px solid #333; }
.book-details { padding: 15px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; }
.book-details h3 { margin: 0 0 10px 0; font-size: 1.1rem; color: var(--highlight-color); line-height: 1.4; }
.book-info { font-size: 0.85rem; color: #aaa; margin-bottom: 15px; }

.view-btn {
    background-color: var(--accent-color); color: white; border: none; padding: 10px;
    width: 100%; border-radius: 8px; cursor: pointer; transition: background 0.2s;
    font-size: 0.95rem; font-weight: 600;
}
.view-btn:hover { background-color: var(--accent-hover); }

/* CONTACT */
.contact-wrapper { display: flex; flex-wrap: wrap; justify-content: center; gap: 40px; padding: 20px; }
.contact-info { flex: 1; min-width: 300px; }
.contact-info h3 { color: var(--accent-color); margin-bottom: 20px; }
.contact-form {
    flex: 1; min-width: 300px; max-width: 500px; background-color: var(--card-color);
    padding: 30px; border-radius: 10px; border: 1px solid #333;
}
.contact-form input, .contact-form textarea {
    width: 100%; padding: 12px; margin-bottom: 15px; background-color: #0a0a0a;
    border: 1px solid #333; color: white; border-radius: 5px; box-sizing: border-box;
}
.submit-btn {
    width: 100%; padding: 12px; background-color: var(--highlight-color); border: none;
    font-weight: bold; cursor: pointer; border-radius: 5px;
}

/* FOOTER */
footer { background-color: #050505; padding: 40px 20px; text-align: center; border-top: 1px solid #222; color: #666; }

/* MODAL */
.modal { display: none; position: fixed; z-index: 2500; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.85); backdrop-filter: blur(5px); }
.modal-content {
    background-color: #1a1a1a; margin: 5% auto; padding: 30px; border-radius: 15px;
    max-width: 600px; position: relative; text-align: center; border: 1px solid #444; color: #fff;
    animation: fadeIn 0.3s;
}
.close-btn { position: absolute; top: 15px; right: 20px; font-size: 2rem; cursor: pointer; color: #888; }
.close-btn:hover { color: var(--accent-color); }
.modal-content img { width: 200px; height: 300px; object-fit: cover; margin-bottom: 20px; border-radius: 5px; box-shadow: 0 5px 15px rgba(0,0,0,0.5); }
.modal-details h2 { color: var(--accent-color); margin-bottom: 5px; }
.modal-details h4 { color: #ccc; font-weight: 400; margin-top: 0; }
.modal-details p { color: #aaa; line-height: 1.6; font-size: 0.95rem; }
.read-link {
    display: inline-block; margin-top: 20px; padding: 12px 25px; background-color: var(--highlight-color);
    color: #000; text-decoration: none; border-radius: 5px; font-weight: bold; transition: transform 0.2s; cursor: pointer;
}
.read-link:hover { transform: scale(1.05); background-color: #00e65c; }

/* Mobile Responsive */
@media(max-width: 768px) {
    .nav-links { gap: 2px; }
    .nav-links a { font-size: 0.8rem; padding: 6px 10px; }
    nav { padding: 0 20px; }
    .hero h1 { font-size: 2.5rem; }
    .container { grid-template-columns: 1fr; }
    .main-btn, .sub-btn { font-size: 0.85rem; padding: 8px 15px; }
}

/* === ENHANCEMENTS === */

/* Improved Hero with animated gradient */
.hero {
  background:
    linear-gradient(135deg, rgba(0,0,0,0.82) 0%, rgba(0,0,0,0.60) 100%),
    url("https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&q=80&w=1920") !important;
  background-size: cover !important;
  background-position: center !important;
  min-height: 80vh;
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: "";
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at 50% 120%, rgba(255,99,71,0.12), transparent 60%);
  pointer-events: none;
}

.hero h1 span {
  background: linear-gradient(45deg, tomato, orange, #ffdd57);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: shimmer 4s linear infinite;
  background-size: 200%;
}

@keyframes shimmer {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}



/* ── FLASH BACK BUTTON ─────────────────────────────── */
.flash-nav {
    position: fixed;
    bottom: 28px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 999;
    display: flex;
    gap: 10px;
    animation: flashIn 0.6s cubic-bezier(0.34,1.56,0.64,1) 0.5s both;
}
@keyframes flashIn {
    from { opacity:0; transform: translateX(-50%) translateY(30px); }
    to   { opacity:1; transform: translateX(-50%) translateY(0); }
}
.flash-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 11px 22px;
    border-radius: 50px;
    font-family: 'Poppins', sans-serif;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    border: none;
    cursor: pointer;
    transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
    white-space: nowrap;
    backdrop-filter: blur(12px);
    box-shadow: 0 4px 20px rgba(0,0,0,0.35);
}
.flash-btn:hover {
    transform: translateY(-4px) scale(1.06);
    box-shadow: 0 10px 30px rgba(0,0,0,0.4);
}
.flash-btn:active { transform: scale(0.96); }
.flash-home {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff;
}
.flash-home:hover { background: rgba(255,255,255,0.18); }
.flash-top {
    background: linear-gradient(135deg, tomato, orange);
    color: #fff;
    box-shadow: 0 4px 20px rgba(255,99,71,0.4);
}
.flash-top:hover { box-shadow: 0 10px 30px rgba(255,99,71,0.6); }


/* ── CLASSICS SECTION ───────────────────────────────── */
.classics-grid { max-width: 1200px; margin: 0 auto; padding: 0 24px 80px; }
.classics-row-label {
    font-family: 'Poppins', sans-serif;
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: tomato;
    margin-bottom: 18px;
    padding-left: 4px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.classics-row-label::after { content:''; flex:1; height:1px; background:rgba(255,99,71,0.2); }
.classics-row {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 18px;
    margin-bottom: 12px;
}
/* NEW CARD DESIGN — tall with image area */
.classic-card {
    display: flex;
    flex-direction: column;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px;
    overflow: hidden;
    text-decoration: none;
    color: #f0f0f0;
    transition: all 0.3s ease;
    cursor: pointer;
}
.classic-card:hover {
    background: rgba(255,255,255,0.07);
    border-color: rgba(255,99,71,0.4);
    transform: translateY(-5px);
    box-shadow: 0 16px 40px rgba(0,0,0,0.5);
}
.cc-image-area {
    width: 100%;
    height: 140px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 52px;
    flex-shrink: 0;
    position: relative;
}
.cc-body {
    padding: 14px 16px;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.cc-title {
    font-size: 0.95rem;
    font-weight: 700;
    color: #f0f0f0;
    line-height: 1.3;
}
.cc-author { font-size: 0.75rem; color: #888; }
.cc-desc {
    font-size: 0.78rem;
    color: #aaa;
    line-height: 1.6;
    flex: 1;
    margin-top: 4px;
}
.cc-buttons {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px solid rgba(255,255,255,0.07);
}
.cc-btn-read {
    flex: 1;
    padding: 8px 10px;
    background: rgba(255,99,71,0.15);
    border: 1px solid rgba(255,99,71,0.35);
    border-radius: 8px;
    color: tomato;
    font-size: 0.78rem;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    transition: all 0.2s;
    font-family: 'Poppins', sans-serif;
    cursor: pointer;
}
.cc-btn-read:hover { background: rgba(255,99,71,0.3); color: #fff; }




</style>
</head>
<body>

<!-- NAVBAR -->
<nav>
  <!-- LOGO -->
  <a href="dashboard.php" class="logo" style="text-decoration:none">📚 LIBRARY</a>

  <!-- CENTER LINKS -->
  <ul class="nav-links">
    <li><a href="dashboard.php">🏠 Dashboard</a></li>
    <li><a href="#books" class="active">📖 Browse</a></li>
    <li><a href="#subjects">🎓 Subjects</a></li>
    <li><a href="#contact">✉️ Contact</a></li>
    <li><a href="logout.php" class="nav-cta">Sign Out →</a></li>
  </ul>
</nav>

<!-- HERO -->
<section class="hero" id="home">
  <h1 style="font-size:3.5rem;margin-bottom:20px;text-shadow:2px 2px 10px rgba(0,0,0,0.8)">
    <span>📚 Digital Library</span>
  </h1>
  <p style="font-size:1.2rem;max-width:700px;margin-bottom:30px;color:#ddd">
    Explore thousands of open-access books — novels, science, motivation, and language learning.
  </p>
  <a href="#books" class="cta-btn">Start Reading →</a>
</section>

<!-- FEATURES -->
<h2 class="section-title" id="features">Our Features</h2>
<div class="features">
  <div class="feature-box">
    <h3>📚 Free Books</h3>
    <p>All books are free and open access from verified sources like Project Gutenberg and OpenStax.</p>
  </div>
  <div class="feature-box">
    <h3>🔍 Smart Search</h3>
    <p>Search by title, author, or category instantly across our entire collection.</p>
  </div>

</div>

<!-- BOOK SECTION -->
<h2 class="section-title" id="books">Browse Books</h2>

<div class="filter-section">
  <div class="main-tabs">
    <button class="main-btn active" onclick="switchMainTab('genre', 'All', this)">📚 All Books</button>
    <button class="main-btn" onclick="switchMainTab('genre', 'Novel', this)">📖 Novels</button>
    <button class="main-btn" onclick="switchMainTab('genre', 'Motivation', this)">🌟 Motivation</button>
    <button class="main-btn" onclick="switchMainTab('genre', 'Philosophy', this)">🧠 Philosophy</button>
    <button class="main-btn" onclick="switchMainTab('genre', 'Self-Help', this)">💪 Self-Help</button>
    <button class="main-btn" onclick="switchMainTab('genre', 'Biography', this)">👤 Biography</button>
  </div>
  <div class="sub-tabs" id="subTabsContainer"></div>
</div>

<div class="search-container">
  <input type="text" id="searchInput" placeholder="🔍 Search by title or author...">
</div>

<div class="results-count" id="resultsCount"></div>
<div class="container" id="booksContainer"></div>

<!-- CLASSIC READING SECTION -->
<h2 class="section-title" id="subjects" style="margin-top:80px">Read Classic Books Online</h2>
<p style="text-align:center;color:#aaa;font-size:0.95rem;margin:-10px auto 40px;max-width:600px">
  Click any book below to read it instantly — free, online, no download needed.
</p>
<div class="classics-grid">

  <!-- ROW: NOVELS -->
  <div class="classics-row-label">📖 Classic Novels</div>
  <div class="classics-row">
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#667eea,#764ba2)">📕</div>
      <div class="cc-body">
        <div class="cc-title">Pride and Prejudice</div>
        <div class="cc-author">Jane Austen · 1813</div>
        <div class="cc-desc">A timeless romantic story of love and society in Regency England.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/1342/1342-h/1342-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#f093fb,#f5576c)">🔍</div>
      <div class="cc-body">
        <div class="cc-title">Sherlock Holmes</div>
        <div class="cc-author">Arthur Conan Doyle · 1892</div>
        <div class="cc-desc">Twelve gripping detective stories featuring the legendary Sherlock Holmes.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/1661/1661-h/1661-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#4facfe,#00f2fe)">⚔️</div>
      <div class="cc-body">
        <div class="cc-title">Count of Monte Cristo</div>
        <div class="cc-author">Alexandre Dumas · 1844</div>
        <div class="cc-desc">An epic tale of betrayal, imprisonment, and spectacular revenge.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/1184/1184-h/1184-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#fa709a,#fee140)">🌹</div>
      <div class="cc-body">
        <div class="cc-title">Jane Eyre</div>
        <div class="cc-author">Charlotte Brontë · 1847</div>
        <div class="cc-desc">A passionate orphan governess falls in love with her mysterious employer.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/1260/1260-h/1260-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#a18cd1,#fbc2eb)">⚡</div>
      <div class="cc-body">
        <div class="cc-title">Frankenstein</div>
        <div class="cc-author">Mary Shelley · 1818</div>
        <div class="cc-desc">A scientist creates life raising profound questions about humanity and morality.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/84/84-h/84-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#fccb90,#d57eeb)">🎭</div>
      <div class="cc-body">
        <div class="cc-title">The Picture of Dorian Gray</div>
        <div class="cc-author">Oscar Wilde · 1890</div>
        <div class="cc-desc">A young man sells his soul for eternal beauty while his portrait ages.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/174/174-h/174-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#43e97b,#38f9d7)">🗼</div>
      <div class="cc-body">
        <div class="cc-title">Les Misérables</div>
        <div class="cc-author">Victor Hugo · 1862</div>
        <div class="cc-desc">Ex-convict Jean Valjean's redemption across post-revolutionary France.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/135/135-h/135-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#f7971e,#ffd200)">🥂</div>
      <div class="cc-body">
        <div class="cc-title">The Great Gatsby</div>
        <div class="cc-author">F. Scott Fitzgerald · 1925</div>
        <div class="cc-desc">The tragic story of Jay Gatsby and his obsession in the Jazz Age.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/64317/64317-h/64317-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
  </div>

  <!-- ROW: MOTIVATION -->
  <div class="classics-row-label" style="margin-top:40px">🌟 Motivation & Self-Help</div>
  <div class="classics-row">
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#30cfd0,#330867)">🏛️</div>
      <div class="cc-body">
        <div class="cc-title">Meditations</div>
        <div class="cc-author">Marcus Aurelius · 180 AD</div>
        <div class="cc-desc">Stoic wisdom, resilience, and virtuous living from a Roman Emperor.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/2680/2680-h/2680-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#a1c4fd,#c2e9fb)">💭</div>
      <div class="cc-body">
        <div class="cc-title">As a Man Thinketh</div>
        <div class="cc-author">James Allen · 1903</div>
        <div class="cc-desc">The power of thought and how mindset shapes our character and life.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/5658/5658-h/5658-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#f83600,#f9d423)">🗡️</div>
      <div class="cc-body">
        <div class="cc-title">The Art of War</div>
        <div class="cc-author">Sun Tzu · 500 BC</div>
        <div class="cc-desc">Ancient strategy on leadership and competition beyond the battlefield.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/132/132-h/132-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#56ab2f,#a8e063)">🌲</div>
      <div class="cc-body">
        <div class="cc-title">Walden</div>
        <div class="cc-author">Henry David Thoreau · 1854</div>
        <div class="cc-desc">A meditation on simple living, nature, and self-discovery.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/205/205-h/205-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#ee9ca7,#ffdde1)">✊</div>
      <div class="cc-body">
        <div class="cc-title">Up from Slavery</div>
        <div class="cc-author">Booker T. Washington · 1901</div>
        <div class="cc-desc">Rising from slavery to found the Tuskegee Institute — a true inspiration.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/2376/2376-h/2376-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#ffecd2,#fcb69f)">☯️</div>
      <div class="cc-body">
        <div class="cc-title">The Analects</div>
        <div class="cc-author">Confucius · 475 BC</div>
        <div class="cc-desc">Sayings of Confucius — a guide to ethics and moral living.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/4094/4094-h/4094-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
  </div>

  <!-- ROW: PHILOSOPHY & BIOGRAPHY -->
  <div class="classics-row-label" style="margin-top:40px">🧠 Philosophy & Biography</div>
  <div class="classics-row">
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#4776e6,#8e54e9)">🏺</div>
      <div class="cc-body">
        <div class="cc-title">The Republic</div>
        <div class="cc-author">Plato · 380 BC</div>
        <div class="cc-desc">Plato's masterwork on justice, the ideal state and the philosopher-king.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/1497/1497-h/1497-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#373b44,#4286f4)">⚡</div>
      <div class="cc-body">
        <div class="cc-title">Beyond Good and Evil</div>
        <div class="cc-author">Friedrich Nietzsche · 1886</div>
        <div class="cc-desc">Nietzsche challenges conventional morality and explores the nature of values.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/4363/4363-h/4363-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#c94b4b,#4b134f)">🦅</div>
      <div class="cc-body">
        <div class="cc-title">Autobiography of Benjamin Franklin</div>
        <div class="cc-author">Benjamin Franklin · 1791</div>
        <div class="cc-desc">The witty life of America's founding father — scientist, statesman, inventor.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/20203/20203-h/20203-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
    <div class="classic-card">
      <div class="cc-image-area" style="background:linear-gradient(135deg,#ff9a9e,#fecfef)">☮️</div>
      <div class="cc-body">
        <div class="cc-title">My Experiments with Truth</div>
        <div class="cc-author">Mahatma Gandhi · 1927</div>
        <div class="cc-desc">Gandhi's remarkable journey from shy lawyer to the father of a nation.</div>
        <div class="cc-buttons">
          <a href="https://www.gutenberg.org/files/54836/54836-h/54836-h.htm" target="_blank" class="cc-btn-read">📖 Read Now</a>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- CONTACT -->
<h2 class="section-title" id="contact">Contact Us</h2>
<div class="contact-wrapper">
  <div class="contact-info">
    <h3>Get In Touch</h3>
    <p style="color:#aaa;line-height:1.8;margin-bottom:16px">
      Have questions about our library? Need help finding a book?
      We're here to help you access knowledge freely.
    </p>
    <p style="color:#aaa">📧 mbabaziemma295@gmail.com</p>
    <p style="color:#aaa">📍 Kigali, Rwanda</p>
    <div style="margin-top:24px;padding:16px;background:rgba(255,99,71,0.08);border:1px solid rgba(255,99,71,0.2);border-radius:10px;">
      <p style="color:#ff9a7b;font-size:0.85rem;line-height:1.7">
        ⚡ Message izajya <strong>kuri Gmail yacu</strong> recto — tusubiza vuba!
      </p>
    </div>
  </div>

  <!-- EmailJS Form -->
  <form class="contact-form" id="contactForm">
    <div style="position:relative">
      <input type="text" id="cf_name" placeholder="Amazina yawe" required
             style="width:100%;padding:12px 16px;background:#0f0f0f;border:1px solid #333;color:white;border-radius:8px;font-family:Poppins,sans-serif;margin-bottom:12px;box-sizing:border-box;transition:0.3s;outline:none">
    </div>
    <div style="position:relative">
      <input type="email" id="cf_email" placeholder="Email yawe" required
             style="width:100%;padding:12px 16px;background:#0f0f0f;border:1px solid #333;color:white;border-radius:8px;font-family:Poppins,sans-serif;margin-bottom:12px;box-sizing:border-box;transition:0.3s;outline:none">
    </div>
    <div style="position:relative">
      <input type="text" id="cf_subject" placeholder="Insanganyamatsiko (sujet)" required
             style="width:100%;padding:12px 16px;background:#0f0f0f;border:1px solid #333;color:white;border-radius:8px;font-family:Poppins,sans-serif;margin-bottom:12px;box-sizing:border-box;transition:0.3s;outline:none">
    </div>
    <textarea id="cf_message" rows="5" placeholder="Ubutumwa bwawe..." required
              style="width:100%;padding:12px 16px;background:#0f0f0f;border:1px solid #333;color:white;border-radius:8px;font-family:Poppins,sans-serif;margin-bottom:14px;resize:vertical;box-sizing:border-box;outline:none;transition:0.3s"></textarea>

    <!-- Status messages -->
    <div id="cf_success" style="display:none;background:rgba(76,175,80,0.15);border:1px solid rgba(76,175,80,0.4);border-radius:8px;padding:12px 16px;margin-bottom:12px;color:#81c784;font-size:0.9rem;text-align:center">
      ✅ Message yoherejwe neza kuri Gmail yacu! Turagushinja.
    </div>
    <div id="cf_error" style="display:none;background:rgba(255,77,77,0.15);border:1px solid rgba(255,77,77,0.4);border-radius:8px;padding:12px 16px;margin-bottom:12px;color:#ff8080;font-size:0.9rem;text-align:center">
      ❌ Habaye ikibazo — gerageza nanone cyangwa twandikire kuri: mbabaziemma295@gmail.com
    </div>

    <button type="submit" class="submit-btn" id="cf_btn">
      <span id="cf_btn_text">📨 Ohereza Message →</span>
    </button>
  </form>
</div>

<!-- FOOTER -->
<footer>
  <p>© 2026 Digital Library — Open Knowledge for Everyone</p>
  <p style="margin-top:8px;font-size:0.85rem">Built with ❤️ using PHP & MySQL · Free to use · No sign-up required for reading</p>
</footer>

<!-- EmailJS SDK -->
<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
<script>
  // ── EmailJS Setup ───────────────────────────────────────────────
  // INTAMBWE ZO GUHUZA EMAILJS:
  // 1. Jya kuri https://www.emailjs.com/ → Create free account na Gmail yawe
  // 2. Add Email Service → Hitamo Gmail → Kopi "Service ID" ushyire aha: YOUR_SERVICE_ID
  // 3. Create Email Template → Shyiramo izi variables:
  //      {{from_name}}  {{from_email}}  {{subject}}  {{message}}
  //    Kopi "Template ID" ushyire aha: YOUR_TEMPLATE_ID
  // 4. Account → API Keys → Kopi "Public Key" ushyire aha: YOUR_PUBLIC_KEY

  const EMAILJS_SERVICE_ID  = 'service_nyjxk6c';
  const EMAILJS_TEMPLATE_ID = 'template_q4xttra';
  const EMAILJS_PUBLIC_KEY  = '-Jl237kkSNioYM57E';

  emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });

  document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const name    = document.getElementById('cf_name').value.trim();
    const email   = document.getElementById('cf_email').value.trim();
    const subject = document.getElementById('cf_subject').value.trim();
    const message = document.getElementById('cf_message').value.trim();

    // Validate
    if (!name || !email || !subject || !message) {
      alert('Uzuza amakuru yose mbere yo kohereza!');
      return;
    }

    const btn     = document.getElementById('cf_btn');
    const btnText = document.getElementById('cf_btn_text');
    const success = document.getElementById('cf_success');
    const error   = document.getElementById('cf_error');

    // Loading state
    btn.disabled          = true;
    btnText.textContent   = '⏳ Birashyirwa...';
    success.style.display = 'none';
    error.style.display   = 'none';

    // Send via EmailJS — variables zihuje na template yawe
    emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
      from_name:  name,
      from_email: email,
      subject:    subject,
      message:    message,
      // Extra aliases kugirango template yose ihuze
      name:       name,
      email:      email,
      title:      subject,
    }).then(function(response) {
      console.log('EmailJS OK:', response.status, response.text);
      success.style.display = 'block';
      btnText.textContent   = '✅ Byoherejwe!';
      // Reset form
      document.getElementById('cf_name').value    = '';
      document.getElementById('cf_email').value   = '';
      document.getElementById('cf_subject').value = '';
      document.getElementById('cf_message').value = '';
      // Reset button after 5s
      setTimeout(() => {
        btn.disabled          = false;
        btnText.textContent   = '📨 Ohereza Message →';
        success.style.display = 'none';
      }, 5000);
    }, function(err) {
      console.error('EmailJS Error:', JSON.stringify(err));
      error.style.display   = 'block';
      btn.disabled          = false;
      btnText.textContent   = '📨 Ohereza Message →';
    });
  });

  // Input focus styles
  document.querySelectorAll('#contactForm input, #contactForm textarea').forEach(el => {
    el.addEventListener('focus',  () => el.style.borderColor = 'tomato');
    el.addEventListener('blur',   () => el.style.borderColor = '#333');
  });
</script>

<!-- MODAL -->
<div id="bookModal" class="modal">
  <div class="modal-content">
    <span class="close-btn" onclick="closeModal()">×</span>
    <div id="modal-body"></div>
  </div>
</div>

<!-- SCROLL TO TOP -->
<button class="scroll-top" id="scrollTop" onclick="window.scrollTo({top:0,behavior:'smooth'})">↑</button>

<script>
const imgNovel      = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400";
const imgMotivation = "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=400";
const imgPhilo      = "https://images.unsplash.com/photo-1461360370896-922624d12aa1?auto=format&fit=crop&q=80&w=400";
const imgBio        = "https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&q=80&w=400";
const imgSelf       = "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=400";

let books = [];
// The catalogue is loaded from MySQL through the PHP API, not hardcoded in JavaScript.
fetch('api/books.php')
  .then(response => { if (!response.ok) throw new Error('Could not load books'); return response.json(); })
  .then(rows => {
    books = rows.map(book => ({
      id: book.id,
      title: book.title,
      author: book.author || 'Unknown author',
      year: '—',
      category: book.category || 'Uncategorised',
      desc: book.description || '',
      img: book.category === 'Novel' ? imgNovel : book.category === 'Motivation' ? imgMotivation : book.category === 'Philosophy' ? imgPhilo : book.category === 'Biography' ? imgBio : imgSelf,
      readUrl: book.read_url || '',
      downloadUrl: book.download_url || ''
    }));
    applyFilters();
  })
  .catch(() => { container.innerHTML = "<p style='color:#f88;text-align:center'>Books could not be loaded. Check the database connection and refresh.</p>"; });

// State variables
const escapeHTML = value => String(value ?? '').replace(/[&<>\"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[ch]));
let currentMode = 'genre'; // 'genre' or 'world'
let currentFilterValue = 'All';
const container = document.getElementById('booksContainer');
const subTabsContainer = document.getElementById('subTabsContainer');
const searchInput = document.getElementById('searchInput');

// --- MAIN TAB LOGIC ---
function switchMainTab(mode, value, btnElement) {
    currentMode = mode;
    currentFilterValue = value;

    // Update Main Button Styling
    const buttons = document.querySelectorAll('.main-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    if(btnElement) btnElement.classList.add('active'); // Check if element exists (for initial load)

    // Clear sub-tabs
    subTabsContainer.innerHTML = '';

    // Logic based on Mode
    if (mode === 'world') {
        renderSubTabs('continent');
        applyFilters();
    } else {
        applyFilters();
    }
}

// --- SUB TAB LOGIC ---
function renderSubTabs(type) {
    let items = [];
    if (type === 'continent') {
        items = ['All', 'Africa', 'Asia', 'Europe', 'North America', 'South America', 'Australia', 'Antarctica'];
    }

    items.forEach(item => {
        const btn = document.createElement('button');
        btn.className = 'sub-btn';
        if (item === 'All') btn.classList.add('active');
        btn.innerText = item;
        btn.onclick = function() {
            document.querySelectorAll('.sub-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentFilterValue = item;
            applyFilters();
        };
        subTabsContainer.appendChild(btn);
    });
}

// --- APPLY FILTERS ---
function applyFilters() {
    let result = books;

    if (currentMode === 'genre') {
        if (currentFilterValue !== 'All') {
            result = result.filter(book => book.category === currentFilterValue);
        }
    } else if (currentMode === 'world') {
        if (currentFilterValue !== 'All') {
            result = result.filter(book => book.continent === currentFilterValue);
        }
    }

    renderBooks(result, currentMode);
}

// Render Books Function
function renderBooks(booksToRender, mode) {
    container.innerHTML = "";
    if(booksToRender.length === 0) {
        container.innerHTML = "<p style='text-align:center; width:100%; color:#666; grid-column: 1/-1; font-size:1.2rem;'>No books found in this folder.</p>";
        return;
    }

    booksToRender.forEach(book => {
        const card = document.createElement('div');
        card.classList.add('book-card');
        
        let continentBadgeHTML = '';
        if (mode === 'world') {
            continentBadgeHTML = `<span class="continent-badge" style="display:block">${book.continent}</span>`;
        }

        card.innerHTML = `
            ${continentBadgeHTML}
            <span class="category-badge">${escapeHTML(book.category)}</span>
            <img src="${escapeHTML(book.img)}" alt="${escapeHTML(book.title)}">
            <div class="book-details">
                <div>
                    <h3>${escapeHTML(book.title)}</h3>
                    <div class="book-info">
                        <p><strong>Author:</strong> ${escapeHTML(book.author)}</p>
                        <p><strong>Year:</strong> ${escapeHTML(book.year)}</p>
                    </div>
                </div>
                <button class="view-btn" type="button">View Details</button>
            </div>
        `;
        card.querySelector('.view-btn').addEventListener('click', () => openModal(book));
        container.appendChild(card);
    });
}

// Search Logic
searchInput.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();
    
    let baseList = books;
    if (currentMode === 'genre' && currentFilterValue !== 'All') {
        baseList = baseList.filter(book => book.category === currentFilterValue);
    } else if (currentMode === 'world' && currentFilterValue !== 'All') {
        baseList = baseList.filter(book => book.continent === currentFilterValue);
    }

    const filteredBooks = baseList.filter((book) => {
        return (
            book.title.toLowerCase().includes(searchString) || 
            book.author.toLowerCase().includes(searchString)
        );
    });
    renderBooks(filteredBooks, currentMode);
});

// Reader Logic
function openSideReader(url, title) {
    if (url) window.open(url, '_blank', 'noopener');
}


// Modal Logic
function openModal(book) {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <img src="${book.img}" alt="Book Cover">
        <div class="modal-details">
            <h2>${escapeHTML(book.title)}</h2>
            <h4>${escapeHTML(book.author)}</h4>
            <p>${escapeHTML(book.desc || '')}</p>
            <p><strong>Category:</strong> ${escapeHTML(book.category)}</p>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px">
              ${book.readUrl ? `<a class="view-btn" href="${escapeHTML(book.readUrl)}" target="_blank" rel="noopener">Read book</a>` : ''}
              ${book.id ? `<a class="view-btn" href="download.php?id=${encodeURIComponent(book.id)}">Download / record</a>` : ''}
            </div>
        </div>`;
    document.getElementById('bookModal').style.display = 'flex';
}
function closeModal() {
    const modal = document.getElementById('bookModal');
    if (modal) modal.style.display = 'none';
}
window.addEventListener('click', function(event) {
    const modal = document.getElementById('bookModal');
    if (event.target === modal) closeModal();
});
</script>
</body>
</html>
