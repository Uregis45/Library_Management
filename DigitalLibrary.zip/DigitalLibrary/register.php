<?php
require_once __DIR__.'/config/db.php'; require_once __DIR__.'/includes/auth.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $firstname=trim($_POST['firstname']??''); $secondname=trim($_POST['secondname']??''); $email=trim($_POST['email']??''); $username=trim($_POST['username']??''); $password=$_POST['password']??''; $confirm=$_POST['confirm_password']??'';
 if ($firstname==='' || $secondname==='') $error='Please enter your first and last name.';
 elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) $error='Please enter a valid email address.';
 elseif ($username==='' || preg_match('/\s/',$username)) $error='Username cannot contain spaces.';
 elseif (strlen($password)<6) $error='Password must be at least 6 characters.';
 elseif ($password!==$confirm) $error='Passwords do not match.';
 else { try { $st=$pdo->prepare('INSERT INTO users(username,password,firstname,secondname,email) VALUES(?,?,?,?,?)'); $st->execute([$username,password_hash($password,PASSWORD_DEFAULT),$firstname,$secondname,$email]); header('Location: signin.php?registered=1'); exit; } catch(PDOException $e) { $error=$e->getCode()==='23000'?'Username or email is already registered.':'Registration failed. Please try again.'; } }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Library Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(rgba(0,0,0,0.72), rgba(0,0,0,0.72)),
                        url('book.jpg') no-repeat center center/cover;
            color: white;
        }
        .container {
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(18px);
            padding: 40px 38px;
            border-radius: 22px;
            width: 90%;
            max-width: 440px;
            box-shadow: 0 25px 60px rgba(0,0,0,0.7);
            border: 1px solid rgba(255,255,255,0.12);
            animation: fadeIn 0.8s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(25px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .logo {
            text-align: center;
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(45deg, tomato, orange);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 4px;
            letter-spacing: 2px;
        }
        h2 {
            text-align: center;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 20px;
            color: #fff;
        }
        .input-group {
            position: relative;
            margin-bottom: 12px;
        }
        .input-group span {
            position: absolute;
            left: 14px;
            top: 14px;
            font-size: 1.1rem;
            pointer-events: none;
        }
        input {
            width: 100%;
            padding: 11px 12px 11px 44px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 10px;
            color: white;
            font-size: 0.93rem;
            font-family: 'Poppins', sans-serif;
            transition: 0.3s;
            outline: none;
        }
        input::placeholder { color: #aaa; }
        input:focus {
            border-color: tomato;
            background: rgba(255,255,255,0.15);
            box-shadow: 0 0 15px rgba(255,99,71,0.3);
        }
        input.error-field {
            border-color: #ff4d4d !important;
            box-shadow: 0 0 12px rgba(255,77,77,0.3) !important;
        }
        input.ok-field {
            border-color: #4caf50 !important;
        }
        .field-error {
            color: #ff8080;
            font-size: 0.76rem;
            margin-top: 4px;
            margin-left: 4px;
            display: none;
        }
        .field-error.show { display: block; }
        button[type="submit"] {
            width: 100%;
            padding: 13px;
            background: linear-gradient(45deg, tomato, orange);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            transition: 0.3s;
            margin-top: 8px;
            box-shadow: 0 8px 20px rgba(255,99,71,0.4);
        }
        button[type="submit"]:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(255,99,71,0.6);
        }
        .link {
            text-align: center;
            margin-top: 16px;
            font-size: 0.9rem;
            color: #bbb;
        }
        .link a { color: tomato; text-decoration: none; font-weight: 600; }
        .link a:hover { text-decoration: underline; }
        .server-error {
            background: rgba(255,77,77,0.15);
            border: 1px solid rgba(255,77,77,0.4);
            border-radius: 8px;
            padding: 10px 14px;
            margin-bottom: 14px;
            font-size: 0.85rem;
            color: #ff9090;
            text-align: center;
        }
        /* Success overlay */
        .success-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.7);
            backdrop-filter: blur(6px);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            gap: 14px;
        }
        .success-overlay.show { display: flex; }
        .success-box {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 18px;
            padding: 40px 50px;
            text-align: center;
            animation: popIn 0.5s cubic-bezier(0.34,1.56,0.64,1);
        }
        @keyframes popIn {
            from { opacity:0; transform: scale(0.7); }
            to   { opacity:1; transform: scale(1); }
        }
        .success-box .check { font-size: 3.5rem; }
        .success-box h3 { font-size: 1.4rem; font-weight: 700; margin: 10px 0 6px; }
        .success-box p  { font-size: 0.9rem; color: #ccc; }
        .progress-bar {
            width: 240px;
            height: 5px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            overflow: hidden;
            margin-top: 20px;
        }
        .progress-fill {
            height: 100%;
            width: 0%;
            background: linear-gradient(45deg, tomato, orange);
            border-radius: 10px;
            transition: width 2s linear;
        }
    </style>
</head>
<body>

    <!-- Success overlay — shown after successful registration -->
    <div class="success-overlay" id="successOverlay">
        <div class="success-box">
            <div class="check">✅</div>
            <h3>Account Created!</h3>
            <p>Redirecting to Sign In…</p>
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill"></div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="logo">📚 DIGITAL LIBRARY</div>
        <h2>Create Account</h2>

        <?php if (!empty($error)): ?><div class="server-error">⚠️ <?=e($error)?></div><?php endif; ?>

        <form id="registerForm" action="register.php" method="POST" novalidate>
            <div class="input-group">
                <span>👤</span>
                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
                <div class="field-error" id="err-firstname">Please enter your first name.</div>
            </div>
            <div class="input-group">
                <span>👤</span>
                <input type="text" id="secondname" name="secondname" placeholder="Last Name" required>
                <div class="field-error" id="err-secondname">Please enter your last name.</div>
            </div>
            <div class="input-group">
                <span>📧</span>
                <input type="email" id="email" name="email" placeholder="Email Address" required>
                <div class="field-error" id="err-email">Please enter a valid email (must contain @).</div>
            </div>
            <div class="input-group">
                <span>🔖</span>
                <input type="text" id="username" name="username" placeholder="Choose Username (no spaces)" required>
                <div class="field-error" id="err-username">Username cannot contain spaces.</div>
            </div>
            <div class="input-group">
                <span>🔒</span>
                <input type="password" id="password" name="password" placeholder="Choose Password (min 6 chars)" required>
                <div class="field-error" id="err-password">Password must be at least 6 characters.</div>
            </div>
            <div class="input-group">
                <span>🔒</span>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                <div class="field-error" id="err-confirm">Passwords do not match.</div>
            </div>
            <button type="submit">Register →</button>
        </form>

        <div class="link">
            <p>Already have an account? <a href="signin.php">Sign In</a></p>
        </div>
    </div>

    <script>
        const form = document.getElementById('registerForm');

        function showError(id, show) {
            document.getElementById(id).classList.toggle('show', show);
        }
        function markField(id, hasError) {
            const el = document.getElementById(id);
            el.classList.toggle('error-field', hasError);
            el.classList.toggle('ok-field', !hasError && el.value.length > 0);
        }

        /* Live validation */
        document.getElementById('firstname').addEventListener('input', function() {
            const ok = this.value.trim().length > 0;
            showError('err-firstname', !ok); markField('firstname', !ok);
        });
        document.getElementById('secondname').addEventListener('input', function() {
            const ok = this.value.trim().length > 0;
            showError('err-secondname', !ok); markField('secondname', !ok);
        });
        document.getElementById('email').addEventListener('input', function() {
            const ok = this.value.includes('@') && this.value.includes('.');
            if (this.value.length > 0) { showError('err-email', !ok); markField('email', !ok); }
        });
        document.getElementById('username').addEventListener('input', function() {
            const ok = this.value.trim().length > 0 && !this.value.includes(' ');
            if (this.value.length > 0) { showError('err-username', !ok); markField('username', !ok); }
        });
        document.getElementById('password').addEventListener('input', function() {
            const ok = this.value.length >= 6;
            if (this.value.length > 0) { showError('err-password', !ok); markField('password', !ok); }
            const conf = document.getElementById('confirm_password').value;
            if (conf.length > 0) { showError('err-confirm', conf !== this.value); markField('confirm_password', conf !== this.value); }
        });
        document.getElementById('confirm_password').addEventListener('input', function() {
            const pw = document.getElementById('password').value;
            const ok = this.value === pw && this.value.length > 0;
            if (this.value.length > 0) { showError('err-confirm', !ok); markField('confirm_password', !ok); }
        });

        /* Validate in the browser, then let PHP securely process the form. */
        form.addEventListener('submit', function(e) {
            let valid = true;
            const checks = [
              ['firstname', v => v.trim().length > 0, 'err-firstname'],
              ['secondname', v => v.trim().length > 0, 'err-secondname'],
              ['email', v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), 'err-email'],
              ['username', v => v.trim().length > 0 && !/\s/.test(v), 'err-username'],
              ['password', v => v.length >= 6, 'err-password'],
              ['confirm_password', v => v === document.getElementById('password').value, 'err-confirm']
            ];
            checks.forEach(([id, test, err]) => { const ok=test(document.getElementById(id).value); showError(err,!ok); markField(id,!ok); if(!ok) valid=false; });
            if (!valid) e.preventDefault();
        });
    </script>
</body>
</html>