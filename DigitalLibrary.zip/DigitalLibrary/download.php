<?php
require_once __DIR__.'/config/db.php'; require_once __DIR__.'/includes/auth.php'; require_login();
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT); if(!$id){http_response_code(400);exit('Invalid book.');}
$st=$pdo->prepare('SELECT id,title,download_url,read_url FROM books WHERE id=?');$st->execute([$id]);$book=$st->fetch();if(!$book){http_response_code(404);exit('Book not found.');}
$log=$pdo->prepare('INSERT INTO downloads(user_id,book_id) VALUES(?,?)');$log->execute([$_SESSION['user_id'],$id]);
$url=$book['download_url'] ?: $book['read_url']; if(!$url || !filter_var($url,FILTER_VALIDATE_URL) || !in_array(parse_url($url,PHP_URL_HOST),['www.gutenberg.org','gutenberg.org'],true)){http_response_code(404);exit('No valid download link is available.');}
header('Location: '.$url);exit;
