<?php
require __DIR__.'/config/db.php';
require __DIR__.'/includes/auth.php';
$count=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$message='';
if ($_SERVER['REQUEST_METHOD']==='POST' && $count===0) {
 $username=trim($_POST['username']??''); $password=$_POST['password']??''; $email=trim($_POST['email']??'');
 if ($username==='' || strlen($password)<8 || !filter_var($email,FILTER_VALIDATE_EMAIL)) $message='Enter a username, valid email and password of at least 8 characters.';
 else { $st=$pdo->prepare("INSERT INTO users(username,password,firstname,secondname,email,role) VALUES(?,?,?,?,?,'admin')"); $st->execute([$username,password_hash($password,PASSWORD_DEFAULT),'Library','Administrator',$email]); $message='Administrator created. Delete setup_admin.php now, then sign in.'; $count=1; }
}
?><!doctype html><html><head><meta charset="utf-8"><title>Initial Admin Setup</title><style>body{background:#101014;color:#eee;font:16px Arial;display:grid;place-items:center;min-height:100vh}.panel{background:#202027;padding:30px;border-radius:14px;width:min(420px,90%)}input,button{display:block;width:100%;padding:12px;margin:12px 0;box-sizing:border-box;border-radius:6px}button{background:tomato;color:white;border:0}</style></head><body><div class="panel"><h2>Library Admin Setup</h2><p><?=e($message)?></p><?php if(!$count):?><form method="post"><input name="username" placeholder="Admin username" required><input type="email" name="email" placeholder="Admin email" required><input type="password" name="password" placeholder="Password (8+ characters)" required><button>Create administrator</button></form><?php else:?>Administrator setup is already complete. Delete this file. <a href="signin.php">Sign in</a><?php endif;?></div></body></html>
