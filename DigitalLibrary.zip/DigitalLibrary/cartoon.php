<?php require_once __DIR__.'/includes/auth.php'; require_login(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Digital Library</title>

<style>
:root{
    --green:#22c55e;
    --green-soft:#4ade80;
    --dark:#020617;
    --glass:rgba(255,255,255,0.06);
    --border:rgba(34,197,94,0.35);
    --text:#e5e7eb;
    --muted:#9ca3af;
}

*{
    box-sizing:border-box;
}

body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    background:
      radial-gradient(circle at top, #022c22, transparent 45%),
      radial-gradient(circle at bottom, #020617, transparent 45%),
      #020617;
    font-family: "Segoe UI", system-ui, sans-serif;
    color:var(--text);
}

/* MAIN SECTION */
.filter-section{
    width:95%;
    max-width:1200px;
    padding:45px 35px;
    border-radius:22px;
    background:linear-gradient(135deg,
        rgba(255,255,255,0.08),
        rgba(255,255,255,0.02));
    backdrop-filter: blur(14px);
    border:1px solid var(--border);
    box-shadow:
        0 30px 60px rgba(0,0,0,0.65),
        inset 0 0 40px rgba(34,197,94,0.06);
}

/* TITLE */
.library-title{
    text-align:center;
    margin-bottom:10px;
    font-size:2.2rem;
    font-weight:800;
    letter-spacing:1px;
    background:linear-gradient(135deg,var(--green),var(--green-soft));
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

/* SUBTITLE */
.library-subtitle{
    text-align:center;
    font-size:1rem;
    color:var(--muted);
    margin-bottom:35px;
}

/* TABS */
.main-tabs{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:16px;
    margin-bottom:30px;
}

/* BUTTONS */
.main-btn{
    position:relative;
    padding:13px 28px;
    border-radius:999px;
    text-decoration:none;
    font-size:15px;
    font-weight:600;
    letter-spacing:0.4px;
    color:var(--text);
    background:var(--glass);
    border:1px solid var(--border);
    transition:all .35s ease;
    overflow:hidden;
}

/* LIGHT SWEEP */
.main-btn::before{
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(
        120deg,
        transparent,
        rgba(255,255,255,0.35),
        transparent
    );
    transform:translateX(-100%);
    transition:.6s;
}

.main-btn:hover::before{
    transform:translateX(100%);
}

/* HOVER */
.main-btn:hover{
    background:linear-gradient(135deg,var(--green),var(--green-soft));
    color:#020617;
    transform:translateY(-3px) scale(1.06);
    box-shadow:
        0 0 22px rgba(34,197,94,0.7),
        0 0 45px rgba(34,197,94,0.35);
}

/* ACTIVE */
.main-btn.active{
    background:linear-gradient(135deg,var(--green),var(--green-soft));
    color:#020617;
    box-shadow:0 0 28px rgba(34,197,94,0.9);
}

/* DIVIDER TEXT */
.section-divider{
    text-align:center;
    margin:35px 0;
    font-weight:700;
    letter-spacing:2px;
    color:var(--green-soft);
    position:relative;
}

.section-divider::before,
.section-divider::after{
    content:"";
    position:absolute;
    top:50%;
    width:30%;
    height:2px;
    background:linear-gradient(to right,transparent,var(--green));
}

.section-divider::after{
    right:0;
    background:linear-gradient(to left,transparent,var(--green));
}

.section-divider::before{
    left:0;
}

/* RESPONSIVE */
@media(max-width:600px){
    .library-title{
        font-size:1.8rem;
    }
    .main-btn{
        padding:11px 20px;
        font-size:14px;
    }
}
</style>
</head>

<body>

<div class="filter-section">

    <div class="library-title">Digital Library</div>
    <div class="library-subtitle">
        Choose the book you want from the genre and country you prefer
    </div>

  

    <div class="main-tabs">
        <a href="library/math.php" class="main-btn">Mathematics</a>
        <a href="library/phyisc.php" class="main-btn">Physics</a>
        <a href="library/chemisrty.php" class="main-btn">Chemistry</a>
        <a href="library/geo.php" class="main-btn">Geographical</a>
        <a href="library/biology.php" class="main-btn">Biology</a>
        <a href="library/computer.php" class="main-btn">Computer Science</a>
        <a href="library/english.php" class="main-btn">Language Learning</a>
    </div>

</div>

</body>
</html>
