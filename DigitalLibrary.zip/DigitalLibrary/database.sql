CREATE DATABASE IF NOT EXISTS digital_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE digital_library;
CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, firstname VARCHAR(100) NOT NULL, secondname VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, role ENUM('user','admin') NOT NULL DEFAULT 'user', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS books (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, author VARCHAR(180) DEFAULT '', category VARCHAR(100) DEFAULT '', description TEXT, read_url TEXT, download_url TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_books_title(title), INDEX idx_books_category(category)) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS downloads (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, book_id INT NOT NULL, downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE) ENGINE=InnoDB;
INSERT INTO books (title,author,category,description,read_url,download_url) VALUES
('Pride and Prejudice','Jane Austen','Novel','A classic romance novel.','https://www.gutenberg.org/files/1342/1342-h/1342-h.htm','https://www.gutenberg.org/ebooks/1342.epub.images'),
('Frankenstein','Mary Shelley','Novel','The story of the modern Prometheus.','https://www.gutenberg.org/files/84/84-h/84-h.htm','https://www.gutenberg.org/ebooks/84.epub.images'),
('The Great Gatsby','F. Scott Fitzgerald','Novel','Jazz Age decadence and the American Dream.','https://www.gutenberg.org/files/64317/64317-h/64317-h.htm','https://www.gutenberg.org/ebooks/64317.epub.images'),
('Moby Dick','Herman Melville','Novel','The obsessive quest of Captain Ahab.','https://www.gutenberg.org/files/2701/2701-h/2701-h.htm','https://www.gutenberg.org/ebooks/2701.epub.images'),
('The Adventures of Tom Sawyer','Mark Twain','Novel','Adventures of a young boy in Missouri.','https://www.gutenberg.org/files/74/74-h/74-h.htm','https://www.gutenberg.org/ebooks/74.epub.images'),
('A Tale of Two Cities','Charles Dickens','Novel','Set during the French Revolution.','https://www.gutenberg.org/files/98/98-h/98-h.htm','https://www.gutenberg.org/ebooks/98.epub.images'),
('Jane Eyre','Charlotte Bronte','Novel','A governess and her mysterious employer.','https://www.gutenberg.org/files/1260/1260-h/1260-h.htm','https://www.gutenberg.org/ebooks/1260.epub.images'),
('Dracula','Bram Stoker','Novel','The iconic vampire horror story.','https://www.gutenberg.org/files/345/345-h/345-h.htm','https://www.gutenberg.org/ebooks/345.epub.images'),
('The Picture of Dorian Gray','Oscar Wilde','Novel','A portrait ages while its subject stays young.','https://www.gutenberg.org/files/174/174-h/174-h.htm','https://www.gutenberg.org/ebooks/174.epub.images'),
('Wuthering Heights','Emily Bronte','Novel','A dark tale of love and revenge on the moors.','https://www.gutenberg.org/files/768/768-h/768-h.htm','https://www.gutenberg.org/ebooks/768.epub.images'),
('Think and Grow Rich','Napoleon Hill','Motivation','Principles of personal success and wealth.','https://www.gutenberg.org/files/1232/1232-h/1232-h.htm','https://www.gutenberg.org/ebooks/1232.epub.images'),
('As a Man Thinketh','James Allen','Motivation','The power of thought in shaping your life.','https://www.gutenberg.org/files/4507/4507-h/4507-h.htm','https://www.gutenberg.org/ebooks/4507.epub.images'),
('The Art of War','Sun Tzu','Motivation','Ancient wisdom for modern strategy.','https://www.gutenberg.org/files/132/132-h/132-h.htm','https://www.gutenberg.org/ebooks/132.epub.images'),
('Meditations','Marcus Aurelius','Philosophy','Stoic philosophy from a Roman emperor.','https://www.gutenberg.org/files/2680/2680-h/2680-h.htm','https://www.gutenberg.org/ebooks/2680.epub.images'),
('The Republic','Plato','Philosophy','Plato\'s dialogue on justice and the ideal state.','https://www.gutenberg.org/files/1497/1497-h/1497-h.htm','https://www.gutenberg.org/ebooks/1497.epub.images'),
('Autobiography of Benjamin Franklin','Benjamin Franklin','Biography','Life story of one of America\'s founders.','https://www.gutenberg.org/files/20203/20203-h/20203-h.htm','https://www.gutenberg.org/ebooks/20203.epub.images'),
('The Power of Now','Eckhart Tolle','Self-Help','Living in the present moment.','https://www.gutenberg.org/files/21765/21765-h/21765-h.htm','https://www.gutenberg.org/ebooks/21765.epub.images'),
('Walden','Henry David Thoreau','Self-Help','Simple living in natural surroundings.','https://www.gutenberg.org/files/205/205-h/205-h.htm','https://www.gutenberg.org/ebooks/205.epub.images');
-- Default administrator is created by setup_admin.php on first run.
