# Digital Library Management System (PHP + MySQL)

## Technology
- HTML5, CSS3 and JavaScript (existing interface retained)
- PHP 8+
- MySQL/MariaDB through XAMPP

## XAMPP installation
1. Install and open XAMPP. Start **Apache** and **MySQL**.
2. Copy this entire `new` folder into `C:\xampp\htdocs\` (you can rename it `DigitalLibrary`).
3. Open `http://localhost/phpmyadmin`. Create/import the database by choosing **Import** and selecting `database.sql`. The SQL creates `digital_library` and inserts the original 18 sample books.
4. Check `config/db.php`. Default XAMPP credentials are host `localhost`, user `root`, empty password. Change `$dbpass` if your MySQL root account has a password.
5. Visit `http://localhost/DigitalLibrary/setup_admin.php`. Create the first administrator (password must be at least 8 characters).
6. **Delete `setup_admin.php` after creating the administrator.**
7. Open `http://localhost/DigitalLibrary/wel.php`. Register a normal user or sign in as the administrator.

## Main pages
- `wel.php`: welcome page
- `register.php` / `signin.php`: registration and login
- `dashboard.php`: subject dashboard
- `index.php`: book catalogue
- `admin.php`: administrator book management (admin role only)
- `api/books.php`: authenticated JSON book search/filter endpoint
- `download.php?id=BOOK_ID`: records download then opens the book download link

## Important notes
- The old Python Flask backend and SQLite database have been removed.
- Existing HTML pages were changed to PHP pages so PHP can handle sessions and forms; their CSS and layout were kept.
- Accounts from the old SQLite database are not imported because the original application stored passwords as plain text. Users should register again. The original sample books are imported.
- The catalogue page retains its original book-card layout. The authenticated API is available for dynamic catalogue integration.
- This project is intended for local XAMPP learning/testing. Before public hosting, configure HTTPS, strong database credentials, backups, and production error logging.
